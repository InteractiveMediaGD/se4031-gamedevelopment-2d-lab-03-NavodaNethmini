using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int damage = 20;
    private ScoreManager scoreManager;

    void Start()
    {
        // Find the ScoreManager once
        scoreManager = Object.FindFirstObjectByType<ScoreManager>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Enemy touched: " + other.name + " | Tag: " + other.tag);


        // projectile hit

        if (other.CompareTag("Projectile"))
        {
            Debug.Log("Projectile detected. Destroying enemy + adding score.");

            if (scoreManager != null)
            {
                scoreManager.AddScore(5);
            }

            Destroy(other.gameObject);              // destroy projectile
            Destroy(transform.root.gameObject);     // destroy entire enemy
            return;
        }


        // player hit

        PlayerHealth player = other.GetComponentInParent<PlayerHealth>();

        if (player != null)
        {
            Debug.Log("Player detected. Damage applied.");

            player.TakeDamage(damage);
            Destroy(transform.root.gameObject);     // destroy entire enemy
        }
        else
        {
            Debug.Log("Collision happened but not player.");
        }
    }

    void Update()
    {
        if (transform.position.x < -10f)
        {
            Destroy(transform.root.gameObject);
        }
    }
}